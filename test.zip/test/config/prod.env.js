'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // API:'"https://sq.ptnetwork001.com"'
}
