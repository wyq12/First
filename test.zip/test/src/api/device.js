import util from '@/libs/util.js'

const service = util.ajax
export function devicePagePort(params){
    return service({
        url:'/cisp_ppt/wxp/WXP290400ScheduleLog.do?method=devicePage',
        method:'GET',
        params
    })
}
export function createDiploms (lawCaseId) {
    const params = {
        lawCaseId
    };
    return service({
        url: '/court/createCase/createDiploms.jhtml',
        method: 'get',
        params
    });
}
