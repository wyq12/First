const getters = {
    avatar: state => state.user.avatar,
};
export default getters;